<?php 
	
	// To change into 0 in production or comment the two lines out
	ini_set('display_errors',0);
 	error_reporting(E_ALL);
	
	define("DS", DIRECTORY_SEPARATOR);
	define('ROOT', __DIR__.'/');

	//Change the SITE_PATH with yours
	//It can be http://localhost/theprojectfolder
	define("SITE_PATH","/"); 
	